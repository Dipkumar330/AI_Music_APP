const express = require('express');
const router = express.Router();

// POST /generate-melody
router.post('/generate-melody', (req, res) => {
  const { mood, genre } = req.body;
  res.json({
    success: true,
    mood,
    genre,
    generatedMelody: "MIDI: C4 - G4 - A4 - E4"
  });
});

// POST /generate-lyrics
router.post('/generate-lyrics', (req, res) => {
  const { theme } = req.body;
  res.json({
    success: true,
    theme,
    generatedLyrics: "Waves crashing, dreams flying high under the neon sky..."
  });
});

// POST /voice-to-melody
router.post('/voice-to-melody', (req, res) => {
  res.json({
    success: true,
    message: "Voice input processed successfully.",
    generatedMelody: "MIDI: E4 - F4 - G4 - A4"
  });
});

// GET /user-projects
router.get('/user-projects', (req, res) => {
  res.json({
    success: true,
    projects: [
      { project_id: "proj1", title: "Happy Vibes", mood: "Happy", genre: "Pop" },
      { project_id: "proj2", title: "Chill Beats", mood: "Relaxed", genre: "Lo-fi" }
    ]
  });
});

module.exports = router;
